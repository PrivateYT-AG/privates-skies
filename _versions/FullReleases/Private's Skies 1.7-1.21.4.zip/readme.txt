Biomes affected by this resourcepack:
To see the colors, search up "color picker" in Google or any other search engine, and copy and paste the hex code.

Desert
Sky: 7254527  / #6EB1FF
Fog: 16772817 / #FFEED1

Bamboo Jungle, Jungle, Sparse Jungle
Sky: 9746943  / #94B9FF
Fog: 12777727 / #C2F8FF

Mangrove Swamp
Sky: 7584964  / #73BCC4
Fog: 11461088 / #AEE1E0

Badlands, Eroded Badlands, Wooded Badlands
Sky: 7254527  / #6EB1FF
Fog: 16766899 / #FFD7B3

Mushroom Fields
Sky: 10122751 / #9A75FF
Fog: 13943551 / #D4C2FF

Ice Spikes, Deep Frozen Ocean, Frozen Ocean, Frozen River, Snowy Beach, Snowy Plains, Snowy Taiga
Sky: 10729456 / #A3B7F0
Fog: 14411007 / #DBE4FF

Swamp
Sky: 6464684  / #62A4AC
Fog: 11461088 / #AEE1E0

Taiga, Old Growth Pine Taiga, Old Growth Spruce Taiga, Windswept Hills, Windswept Gravelly Hills, Windswept Forest
Sky: 9415152  / #8FA9F0
Fog: 13425151 / #CCD9FF

Beach, Meadow, Plains, Cherry Grove, Sunflower Plains, Stony Shore
Sky: 7907327  / #78A7FF
Fog: 12638463 / #C0D8FF

Birch Forest, Dark Forest, Flower Forest, Forest, Old Growth Birch Forest
Sky: 9090047  / #8AB3FF
Fog: 12638463 / #C0D8FF

Frozen Peaks, Grove, Jagged Peaks, Snowy Slopes
Sky: 8360929  / #7F93E1
Fog: 14411007 / #DBE4FF

Stony Peaks
Sky: 7050977  / #6B96E1
Fog: 12638463 / #C0D8FF

Warm Ocean
Sky: 7254527  / #6EB1FF
Fog: 12638463 / #C0D8FF

Lukewarm Ocean, Deep Lukewarm Ocean, Ocean, Deep Ocean
Sky: 8103167  / #7BA4FF
Fog: 12638463 / #C0D8FF

Cold Ocean, Deep Cold Ocean
Sky: 9415152  / #8FA9F0
Fog: 12638463 / #C0D8FF

Deep Dark
Sky: 1719628  / #1A3D4C
Fog: 793892   / #0C1D24

Savanna, Savanna Plateau
Sky: 7254527  / #6EB1FF
Fog: 12446719 / #BDEBFF

Shader compatibility
This pack was tested on two shaders: BSL* and Complementary. They both work fine, except that the fog color doesn't change, so if you go to a mesa the fog wouldn't be orange. Also, the biome's lighting changes in these two shaders, so if you go to a mushroom fields, it would have a purplish tint. If you are using shaders other than these two, then it may or may not work.
*If you turn "Vanilla Sky" to ON

Credits

This pack was inspired by:
Vibrant Sky by barce
https://modrinth.com/resourcepack/vibrant-sky

Fogulous by FusionSwarly
https://modrinth.com/resourcepack/fogulous

Cliff under a Tree (CliffTree) by Konci
https://modrinth.com/datapack/clifftree

If you liked this pack, consider subscribing to my YouTube channels:
https://www.youtube.com/@PrivateYT-AG
https://www.youtube.com/@PrivateYT-GG
https://www.youtube.com/@PrivateYTAlter